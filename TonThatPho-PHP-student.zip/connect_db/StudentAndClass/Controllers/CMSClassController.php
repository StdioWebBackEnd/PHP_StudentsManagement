<?php
include_once "../Models/DBs.php";
include_once "../Models/Class.php";
include_once "../Models/DetailStudent.php";
include_once "../Models/Subject.php";
class CMSClassController
{

    static public function index()
    {
        try {        
            $list_class = Classes::getList();
            $list_subject = Subject::getAllSubject();
            include_once "../Views/Layouts/sidebar-menu.php";
            include_once "../Views/Layouts/header.php";
            include_once "../Views/SufeeAdmin/cms-class.php";
            include_once "../Views/Layouts/footer.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
}