<?php
include_once "../Models/DBs.php";
include_once "../Models/Class.php";
include_once "../Models/DetailStudent.php";
include_once "../Models/Subject.php";
class ClassController
{

    static public function index()
    {
        try {
            $list_class = Classes::getList();
            $list_subject = Subject::getAllSubject();
            include_once "../Views/class/list_class.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function list_student($request)
    {
        try {
            $id_class = $request['id_class'];
            
            $dsSV = DetailStudent::list_student($id_class);
            $class = DetailStudent::nameClass($id_class);
            include_once "../Views/Layouts/sidebar-menu.php";
            include_once "../Views/Layouts/header.php";
            include_once "../Views/class/dssv.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function update($request)
    {
        try {
            //code...
            if (!$request['name'] || !$request['subject']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }

            $id = $request['id'];

            $class = new Classes($id, $request['name'], $request['subject']);
            $result = Classes::update($class);
            var_dump($result);

            header('Location: ' . 'cms-class');
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function Edit($id)
    {
        try {
            $id = 0;
            if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
                $id = $_GET['id'];
                $class = Classes::getbyid($id);
                $list_subject = Subject::getAllSubject();
                include_once "../Views/Layouts/sidebar-menu.php";
                include_once "../Views/Layouts/header.php";
                include_once "../Views/class/edit-class.php";
            }
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function add($request)
    {
        try {
            //code...
            if (!$request['name'] || !$request['subject']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }
            $class = new Classes(null, $request['name'], $request['subject']);
            $result = Classes::add($class);
            var_dump($result);
            header('Location: ' . $_SERVER['HTTP_REFERER']);
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function delete($id){
        $id = 0;
        if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] >0){
            $id=$_GET['id'];

            Classes::delete($id);
        }
        include_once "../Views/deleteclass.php";
        header('Location: ' . $_SERVER['HTTP_REFERER']);
     }

     static public function Search()
     {
         if(isset($_GET['tukhoa'])){
            $key = $_GET['tukhoa'];
            $list_class = Classes::Search($key);
            
         }
         include_once "../Views/class/list_class.php";
     }
}