<?php
include_once "../Models/DBs.php";
include_once "../Models/DetailStudent.php";
include_once "../Models/Class.php";
include_once "../Models/Major.php";
include_once "../Models/Subject.php";
include_once "../Models/Student.php";
class DetailController
{
    static public function index($request)
    {
        try {
            $IDstudent = $request['id_sv'];
            $student = Student::getbyid($IDstudent);
            $listclass = Classes::getList();
            include_once "../Views/Layouts/sidebar-menu.php";
            include_once "../Views/Layouts/header.php";
            include_once "../Views/student/join-class.php";
            include_once "../Views/Layouts/footer.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function joinclass($IDclass, $IDstudent)
    {
        try {
            $result = DetailStudent::joinclass($IDclass, $IDstudent);
            var_dump($result);
            header('Location: ' . 'detail-student?id_sv=' . $IDstudent);
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function getMajor()
    {
        try {

            $list_major = Major::getAllMajor();
            include_once "../Views/Layouts/sidebar-menu.php";
            include_once "../Views/Layouts/header.php";
            include_once "../Views/student/major.php";
            include_once "../Views/Layouts/footer.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function addMajor($request)
    {
        try {
            //code...
            if (!$request['name']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }
            $major = new Major(null, $request['name']);
            $result = Major::add($major);
            var_dump($result);
            header('Location: major');
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function updateMajor($request)
    {
        try {
            //code...
            if (!$request['name']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }

            $id = $request['id'];

            $major = new Major($id, $request['name']);
            $result = Major::update($major);
            var_dump($result);

            header('Location: ' . 'major');
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function editMajor($id)
    {
        try {
            $id = 0;
            if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
                $id = $_GET['id'];
                $major = Major::getbyid($id);
                include_once "../Views/Layouts/sidebar-menu.php";
                include_once "../Views/Layouts/header.php";
                include_once "../Views/student/edit-major.php";
            }
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function deleteMajor($id)
    {
        $id = 0;
        if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
            $id = $_GET['id'];
            Major::delete($id);
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }

    //////// Subject ////////

    static public function getSubject()
    {
        try {

            $list_subject = Subject::getAllSubject();
            include_once "../Views/Layouts/sidebar-menu.php";
            include_once "../Views/Layouts/header.php";
            include_once "../Views/class/subject.php";
            include_once "../Views/Layouts/footer.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function addSubject($request)
    {
        try {
            //code...
            if (!$request['name']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }
            $major = new Subject(null, $request['name']);
            $result = Subject::add($major);
            var_dump($result);
            header('Location: subject');
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function updateSubject($request)
    {
        try {
            //code...
            if (!$request['name']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }

            $id = $request['id'];

            $sub = new Subject($id, $request['name']);
            $result = Subject::update($sub);
            var_dump($result);

            header('Location: ' . 'subject');
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function editSubject($id)
    {
        try {
            $id = 0;
            if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
                $id = $_GET['id'];
                $subject = Subject::getbyid($id);
                include_once "../Views/Layouts/sidebar-menu.php";
                include_once "../Views/Layouts/header.php";
                include_once "../Views/class/edit-subject.php";
            }
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function deleteSubject($id)
    {
        $id = 0;
        if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
            $id = $_GET['id'];
            Subject::delete($id);
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }

    static public function delete($id_sv, $id_class)
    {   
        $id_sv = $_GET['id_sv'];
        $id_class = $_GET['id_class'];
        DetailStudent::delete($id_sv, $id_class);

        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }
}
