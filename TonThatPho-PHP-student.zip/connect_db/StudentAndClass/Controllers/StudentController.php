<?php
include_once "../Models/DBs.php";
include_once "../Models/Student.php";
include_once "../Models/DetailStudent.php";
include_once "../Models/Major.php";
class StudentController
{

    static public function index()
    {
        try {
            //code...
            $list_student = Student::getList();
            $list_major = Major::getAllMajor();
            include_once "../Views/student/list_view.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function getMajor()
    {
        try {
            //code...
            $list_major = Major::getAllMajor();
            include_once "../Views/timkiem.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function listSV($id)
    {
        try {
            if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
                $id = $_GET['id'];
                $dsSV = Student::getbyclass($id);
                include_once "../Views/class/dssv.php";
            }
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function Edit($id)
    {
        try {
            $id = 0;
            if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
                $id = $_GET['id'];
                $student = Student::getbyid($id);
                $list_major = Major::getAllMajor();
                include_once "../Views/Layouts/sidebar-menu.php";
                include_once "../Views/Layouts/header.php";
                include_once "../Views/student/edit-student.php";
            }
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function join()
    {
        include_once "../Views/student/join-class.php";
    }

    static public function Search()
    {
        if(isset($_GET['tukhoa'])){
            $key = $_GET['tukhoa'];
            $list_student = Student::Search($key);
        }
        include_once "../Views/student/list_view.php";
    }
    
    static public function Detail($request)
    {
        try {
            $id_sv = $request['id_sv'];
            $student = Student::getbyid($id_sv);

            $listclass = DetailStudent::list_class($id_sv);
            include_once "../Views/Layouts/sidebar-menu.php";
            include_once "../Views/Layouts/header.php";
            include_once "../Views/student/detail-student.php";
            
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function add($request)
    {
        try {
            //code...
            if (!$request['name'] || !$request['age'] || !$request['major']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }
            $student = new Student(null, $request['name'], $request['age'], $request['major']);
            $result = Student::add($student);
            var_dump($result);
            header('Location: ' . $_SERVER['HTTP_REFERER']);
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }

    static public function update($request)
    {
        try {
            //code...
            if (!$request['name'] || !$request['age'] || !$request['major']) {
                echo "Dữ liệu không hợp lệ";
                return;
            }

            $id = $request['id'];

            $student = new Student($id, $request['name'], $request['age'], $request['major']);
            $result = Student::update($student);
            var_dump($result);

            header('Location: ' . $_SERVER['HTTP_REFERER']);
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function delete()
    {
        $id = 0;
        if (isset($_GET['id']) && $_GET['id'] != null && $_GET['id'] > 0) {
            $id = $_GET['id'];
            Student::delete($id);
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }
}
