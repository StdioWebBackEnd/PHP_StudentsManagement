<?php
include_once "DBs.php";
class DetailStudent
{
    public $IDclass;
    public $IDstudent;
    function __construct($IDclass, $IDstudent)
    {
        $this->IDclass = $IDclass;
        $this->IDstudent = $IDstudent;
    }

    static function joinclass($IDclass, $IDstudent)
    {
        $conn = DB::connect();
        $sql = "INSERT INTO `student_class` (`id_sv`, `id_class`)
                VALUE ('$IDstudent','$IDclass') ";
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return null;
        }
        $conn->close();
        return $result;
    }
    static function nameClass($id_class)
    {
        $conn = DB::connect();
        $sql = "SELECT c.name FROM classes as c WHERE c.id = $id_class ";
        $result = $conn->query($sql);
        $ls = '';
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ls = $result;
            }
        }
        if ($conn->error) {
            echo $conn->error;
            return null;
        }
        $conn->close();
        return $ls;
    }

    static function list_class($id_sv)
    {
        $conn = DB::connect();
        $sql = "SELECT DiSTINCT c.id ,c.name, c.subject 
                FROM students AS s 	JOIN student_class AS sc ON s.id = sc.id_sv 
					JOIN classes AS c ON sc.id_class = c.id
                WHERE sc.id_sv = $id_sv
                ORDER BY c.id ASC    
                ";
         $result = $conn->query($sql);
         $ls = [];
         if ($result->num_rows > 0) {
             while ($row = $result->fetch_assoc()) {
                 $ls[] = new Classes($row['id'], $row['name'], $row['subject']);
             }
         }
         $conn->close();
         return $ls;
    }
    static function list_student($id_class)
    {
        $conn = DB::connect();
        $sql = "SELECT s.id ,s.name, s.age, s.major 
                FROM students AS s 	JOIN student_class AS sc ON s.id = sc.id_sv 
					JOIN classes AS c ON sc.id_class = c.id
                WHERE sc.id_class = $id_class
                ORDER BY s.id ASC    
                ";
        $result = $conn->query($sql);
        $ls = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ls[] = new Student($row['id'], $row['name'], $row['age'], $row['major']);
            }
        }
        $conn->close();
        return $ls;
    }

    static function delete($id_sv, $id_class)
    {
        $conn = DB::connect();
        $sql = "DELETE FROM `student_class` WHERE `id_sv` = $id_sv AND `id_class` = $id_class" ;
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return false;
        }
        $conn->close();
        return $result;
    }
}
