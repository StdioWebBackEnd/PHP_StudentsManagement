<?php
include_once "DBs.php";
class Major
{
    // Properties
    public $id;
    public $name;

    function __construct($id, $name)
    {
        $this->id = $id;
        $this->name = $name;

    }

    static function getAllMajor()
    {
        $conn = DB::connect();
        $sql = "SELECT * FROM major";
        $result = $conn->query($sql);
        $ls = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ls[] = new Major($row['id'], $row['name']);
            }
        }
        $conn->close();
        return $ls;
    }

    static function add($major)
    {
        $conn = DB::connect();
        $sql = "INSERT INTO `major` (`name`) 
                VALUES ('" . $major->name . "')";
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return null;
        }
        $conn->close();
        return $result;
    }

    static function getbyid($id){
        $conn = DB::connect();
        $sql = "SELECT * FROM major WHERE id = " . $id;
        $result = $conn->query($sql);
        $row = mysqli_fetch_array($result);
        $conn->close();
        return $row;
    }

    static function update($major)
    {
        $conn = DB::connect();
        $sql = "UPDATE `major` 
                SET `name` = '" . $major->name . "'
                WHERE `id`= $major->id" ;
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return null;
        }
        $conn->close();
        return $result;
    }

    static function delete($id)
    {
        $conn = DB::connect();
        $sql = "DELETE FROM `major` WHERE `id` = " . $id;
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return false;
        }
        $conn->close();
        return $result;
    }
}