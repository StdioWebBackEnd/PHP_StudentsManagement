<?php
include_once "DBs.php";
class Student
{
    // Properties
    public $id;
    public $name;
    public $age;
    public $major;

    function __construct($id, $name, $age, $major)
    {
        $this->id = $id;
        $this->name = $name;
        $this->age = $age;
        $this->major = $major;
    }

    static function getList()
    {
        $conn = DB::connect();
        $sql = "SELECT * FROM students";
        $result = $conn->query($sql);
        $ls = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ls[] = new Student($row['id'], $row['name'], $row['age'], $row['major']);
            }
        }
        $conn->close();
        return $ls;
    }


    static function getbyclass($id_class){
        $conn = DB::connect();
        $sql="SELECT s.id ,s.name, s.age, s.major 
                FROM student as s 
                JOIN detailstudent as d 
                ON d.id_class = '$id_class' 
                    AND s.id = d.id_sv";
        $result = $conn->query($sql);
        $ls = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ls[] = new Student($row['id'], $row['name'], $row['age'], $row['major']);
            }
        }
        $conn->close();
        return $ls;
    }
    static function getbyid($id){
        $conn = DB::connect();
        $sql = "SELECT * FROM students WHERE id = " . $id;
        $result = $conn->query($sql);
        $row = mysqli_fetch_array($result);
        $conn->close();
        return $row;
    }

    static function add($student)
    {
        $conn = DB::connect();
        $sql = "INSERT INTO `students` (`name`, `age`,`major`) 
                VALUES ('" . $student->name . "',
                        '" . $student->age . "',
                        '" . $student->major . "')";
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return null;
        }
        $conn->close();
        return $result;
    }
    static function update($student)
    {
        $conn = DB::connect();
        $sql = "UPDATE `students` 
                SET `name` = '" . $student->name . "', 
                    `age` = '" . $student->age . "',
                    `major` = '" . $student->major . "'
                WHERE `id`= $student->id" ;
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return null;
        }
        $conn->close();
        return $result;
    }

    static function delete($id)
    {
        $conn = DB::connect();
        $sql = "DELETE FROM `students` WHERE `id` = " . $id ;
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return false;
        }
        $conn->close();
        return $result;
    }
    
    static function Search($key)
    {
        $conn = DB::connect();
        $sql = "SELECT * FROM students WHERE `name` LIKE '%$key%' OR `id` LIKE '%$key%' OR `major` LIKE '%$key%' ORDER BY id ASC ";
        $result = $conn->query($sql);
        $ls = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ls[] = new Student($row['id'], $row['name'], $row['age'], $row['major']);
            }
        }
        $conn->close();
        return $ls;
    }
    static function Count(){
        $conn = DB::connect();
        $sql = "SELECT COUNT(*)
                FROM students
                " ;
        $result = $conn->query($sql);
        if ($conn->error) {
            echo $conn->error;
            return false;
        }
        $conn->close();
        return $result;
    }
}