<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Management</a></li>
                    <li class="active">Class</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated">
        <div class="card">
            <div class="card-body">

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-secondary mb-1" data-toggle="modal" data-target="#mediumModal">
                    Add Class
                </button>
            </div>
        </div>


        <div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <form method="POST" action="./class">
                        <div class="modal-header">
                            <h5 class="modal-title" id="classLabel">Add Class</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Name</label>
                                <input type="text" class="form-control" name="name">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Subject</label>
                                <select class="form-control" name="subject">
                                    <?php
                                    foreach ($list_subject as $list) {
                                    ?>
                                        <option value="<?= $list->name ?>"><?= $list->name ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div><!-- .animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Table</strong>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Subject</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($list_class as $class) {
                                ?>
                                    <tr>
                                        <th scope="row"><?= $class->id ?></th>
                                        <td><?= $class->name ?></td>
                                        <td><?= $class->subject ?></td>
                                        <td>
                                            <a href="./editclass?id=<?= $class->id ?>">
                                                <button class="btn btn-info">edit</button>
                                            </a>
                                            <a href="./dssv?id_class=<?= $class->id ?>">
                                                <button class="btn btn-info">dssv</button>
                                            </a>

                                            <a href="./class?m=delete&id=<?= $class->id ?>" onclick="
                                                        return confirm('Bạn muốn xóa ?'); 
                                                    ">
                                                <button class="btn btn-danger">delete</button>
                                            </a>

                                        </td>
                                    </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->