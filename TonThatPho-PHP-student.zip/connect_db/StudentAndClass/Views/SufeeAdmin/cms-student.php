<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="cms-home">Dashboard</a></li>
                    <li><a href="#">Managements</a></li>
                    <li class="active">Students</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated">
        <div class="card">
            <div class="card-body">

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-secondary mb-1" data-toggle="modal" data-target="#mediumModal">
                    Add student
                </button>
            </div>
        </div>


        <div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <form method="POST" action="./students">
                        <div class="modal-header">
                            <h5 class="modal-title" id="studentLabel">Add Student</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Name</label>
                                <input type="text" class="form-control" name="name">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Major</label>
                                <select class="form-control" name="major">
                                    <?php
                                    foreach ($list_major as $list) {
                                    ?>
                                        <option value="<?= $list->name ?>"><?= $list->name ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">age</label>
                                <input type="text" class="form-control" name="age">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div><!-- .animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Table</strong>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Name</th>
                                    <th>Major</th>
                                    <th>Age</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stt = 1;
                                foreach ($list_student as $student) {
                                ?>
                                    <tr>
                                        <td><?php echo $stt ?></td>
                                        <td><?= $student->name ?></td>
                                        <td><?= $student->major ?></td>
                                        <td><?= $student->age ?></td>
                                        <td>
                                            <form method="POST" action="./join-class">
                                                <input type="hidden" name="id_sv" value="<?= $student->id ?>">
                                                <button type="submit" class="btn btn-primary">joinclass</button>
                                            </form>
                                            <a href="./detail-student?id_sv=<?= $student->id ?>">
                                                <button class="btn btn-info">detail</button>
                                            </a>
                                            <a href="./edit?id=<?= $student->id ?>">
                                                <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#update">
                                                    Edit
                                                </button>
                                            </a>
                                            <a href="./students?m=delete&id=<?= $student->id ?>" onclick="return confirm('Bạn muốn xóa ?')">
                                                <button class="btn btn-danger">delete</button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php $stt++;
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->