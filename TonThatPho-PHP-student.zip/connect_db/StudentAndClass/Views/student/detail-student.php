<body>
    <h4 style="text-align: center;">Thong tin sinh viên <?php echo $student['name'] ?></h4>

    <button style="margin-left: 80%;" type="button" class="btn btn-secondary mb-1" data-toggle="modal" data-target="#mediumModal">
        Edit
    </button>

    <div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">

                <!-- Modal body -->
                <form action="./students?id=<?php echo $student['id'] ?>" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="studentLabel">Add Student</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name: </label>
                            <input class="form-control" type="text" name="name" value="<?php echo $student['name'] ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Major: </label>
                            <input class="form-control" type="text" name="major" value="<?php echo $student['major'] ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Age: </label>
                            <input class="form-control" type="text" name="age" value="<?php echo $student['age'] ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button name="btnUpdate" type="submit" class="btn btn-primary">Submit</button>
                        </div>
                </form>

            </div>
        </div>
    </div>
    <div class="row" style="margin-left: 20%;">
        <label class="control-label col-sm-2">Name:</label>
        <div class="col-sm-10">
            <p class="form-control-static"><?php echo $student['name'] ?></p>
        </div>
        <label class="control-label col-sm-2">Major:</label>
        <div class="col-sm-10">
            <p class="form-control-static"><?php echo $student['major'] ?></p>
        </div>
        <label class="control-label col-sm-2">Age:</label>
        <div class="col-sm-10">
            <p class="form-control-static"><?php echo $student['age'] ?></p>
        </div>
    </div>
    <h6 style="text-align: center;">Class Join</h6>
    <div style="margin-left: 10%; margin-right: 10%;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Subject</th>
                    <th scope="col">
                        <form method="POST" action="./join-class">
                            <input type="hidden" name="id_sv" value="<?= $student['id'] ?>">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($listclass as $classes) {

                ?>
                    <tr>
                        <th scope="row">
                            <?= $classes->id ?>
                        </th>
                        <td><?= $classes->name ?></td>
                        <td><?= $classes->subject ?></td>
                        <td>
                            <a href="./detail-student?m=delete&id_sv=<?= $student['id'] ?>&id_class=<?= $classes->id ?>">Huy</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

    </div>
</body>
<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>


<script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="vendors/jszip/dist/jszip.min.js"></script>
<script src="vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="vendors/pdfmake/build/vfs_fonts.js"></script>
<script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="assets/js/init-scripts/data-table/datatables-init.js"></script>