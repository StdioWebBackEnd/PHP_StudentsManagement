<body>
    <h5 style="margin-top: 20px; margin-left: 50px;"><?php echo $student['name'] ?></h5>
    <div class="container mt-5">
        <div class="modal-header">
            <h5 class="modal-title" id="class_listLabel">Join Class</h5>
        </div>
        <div class="modal-body">
            <div class="mb-3">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Subject</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($listclass as $classes) {

                        ?>
                            <tr>
                                <td><?= $classes->name ?></td>
                                <td><?= $classes->subject ?></td>
                                <td><a href="./students?m=joinclass&id_class=<?= $classes->id ?>&id_sv=<?= $IDstudent ?>" class="btn btn-primary">JOIN</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>