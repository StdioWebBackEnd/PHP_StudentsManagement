<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>List student!</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        * {
            box-sizing: border-box;
        }

        /* Create a column layout with Flexbox */
        .row {
            display: flex;
        }

        /* Left column (menu) */
        .left {
            flex: 15%;
            padding: 20px 20px;
        }

        .left h2 {
            padding-left: 8px;
        }

        /* Right column (page content) */
        .right {
            flex: 65%;
            padding: 15px;
        }

        /* Style the search box */
        #mySearch {
            width: 100%;
            font-size: 18px;
            padding: 11px;
            border: 1px solid #ddd;
        }

        /* Style the navigation menu inside the left column */
        #myMenu {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        #myMenu li a {
            padding: 12px;
            text-decoration: none;
            color: black;
            display: block
        }

        #myMenu li a:hover {
            background-color: #eee;
        }

        .search-input {
            width: 30%;
            height: 45px;
        }

        .f-se button {
            width: 60px;
            padding: 10px;
            background: #2196F3;
            color: white;
            font-size: 17px;
            border: 1px solid grey;
            border-left: none;
            cursor: pointer;
        }

        .f-se button:hover {
            background: #0b7dda;
        }
    </style>
</head>

<body>


    <div class="row">
        <div class="left" style="background-color:#bbb;">
            <h2>Menu</h2>
            <input type="text" id="mySearch" onkeyup="myFunction()" placeholder="Search.." title="Type in a category">
            <ul id="myMenu">
                <li><a href="http://localhost/learn-php/connect_db/StudentAndClass/public/students">Student Management</a></li>
                <li><a href="http://localhost/learn-php/connect_db/StudentAndClass/public/class">Class Management</a></li>
                <li><a href="http://localhost/learn-php/connect_db/StudentAndClass/public/major">Major</a></li>
            </ul>
        </div>

        <div class="right" style="background-color:#f0fbff;">
            <div class="container mt-5">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#student">
                    Add Student
                </button>
                <div class="modal fade" id="student" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="studentLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="./students">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="studentLabel">Add Student</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Name</label>
                                        <input type="text" class="form-control" name="name">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Major</label>
                                        <select class="form-control" name="major">
                                            <?php
                                            foreach ($list_major as $list) {
                                            ?>
                                                <option value="<?= $list->name ?>"><?= $list->name ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">age</label>
                                        <input type="text" class="form-control" name="age">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <form class="f-se" onsubmit="submitFn(this, event);" action="" method="GET">
                <div class="search-wrapper" style="margin-left: 20%;">
                    <div class="input-holder">
                        <input type="hidden" name="m" value="tim-kiem">
                        <input type="text" name="tukhoa" class="search-input" placeholder="Type to search" />
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </div>
                </div>
            </form>
            <!-- Optional JavaScript; choose one of the two! -->

            <div class="container mt-3">
                <div class="row">
                    <div class="col-9">
                        <h1>List student</h1>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">STT</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Major</th>
                                    <th scope="col">Age</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stt = 1;
                                foreach ($list_student as $student) {
                                ?>
                                    <tr>
                                        <td><?php echo $stt ?></td>
                                        <td><?= $student->name ?></td>
                                        <td><?= $student->major ?></td>
                                        <td><?= $student->age ?></td>
                                        <td>
                                            <form method="POST" action="./join-class">
                                                <input type="hidden" name="id_sv" value="<?= $student->id ?>">
                                                <button type="submit" class="btn btn-primary">joinclass</button>
                                            </form>
                                            <a href="./detail-student?id_sv=<?= $student->id ?>">
                                                <button class="btn btn-info">detail</button>
                                            </a>
                                            <a href="./edit?id=<?= $student->id ?>">
                                                <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#update">
                                                    Edit
                                                </button>
                                            </a>
                                            <a href="./students?m=delete&id=<?= $student->id ?>" onclick="return confirm('Bạn muốn xóa ?')">
                                                <button class="btn btn-danger">delete</button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php $stt++;
                                } ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function myFunction() {
            var input, filter, ul, li, a, i;
            input = document.getElementById("mySearch");
            filter = input.value.toUpperCase();
            ul = document.getElementById("myMenu");
            li = ul.getElementsByTagName("li");
            for (i = 0; i < li.length; i++) {
                a = li[i].getElementsByTagName("a")[0];
                if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        }
    </script>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>