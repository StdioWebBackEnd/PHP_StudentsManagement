<?php

$url = isset($_GET['url']) ? $_GET['url'] : "";
$method = $_SERVER['REQUEST_METHOD'];
$root = 'http://localhost/learn-php/connect_db/StudentAndClass/public/cms/table';
include_once "../Controllers/StudentController.php";
include_once "../Controllers/ClassController.php";
include_once "../Controllers/DetailController.php";
include_once "../Controllers/HomeController.php";
include_once "../Controllers/CMSClassController.php";
switch ($url) {
    case 'students':
        if (isset($_GET['m']) && $_GET['m'] == 'delete') {
            StudentController::delete();
        } else if (isset($_POST['btnUpdate'])) {
            StudentController::update($_REQUEST);
            return;
        } else if (isset($_GET['m']) && $_GET['m'] == 'joinclass') {
            $IDstudent = $_REQUEST['id_sv'];
            $IDclass = $_REQUEST['id_class'];
            DetailController::joinclass($IDclass, $IDstudent);
            return;
        } else if (isset($_GET['m']) && $_GET['m'] == 'tim-kiem') {
            StudentController::Search();
            return;
        }
        switch ($method) {
            case 'GET':
                StudentController::index();
                return;
            case 'POST':
                StudentController::add($_REQUEST);
                return;
        }
    case 'dssv':
        switch ($method) {
            case 'GET':
                ClassController::list_student($_REQUEST);
                return;
        }
    case 'edit':
        switch ($method) {
            case 'GET':
                StudentController::Edit($_GET['id']);
                return;
        }
    case 'editclass':
        switch ($method) {
            case 'GET':
                ClassController::Edit($_GET['id']);
                return;
        }
    case 'editmajor':
        switch ($method) {
            case 'GET':
                DetailController::editMajor($_GET['id']);
                return;
        }
    case 'editsubject':
        switch ($method) {
            case 'GET':
                DetailController::editSubject($_GET['id']);
                return;
        }
    case 'detail-student':
        if (isset($_GET['m']) && $_GET['m'] == 'delete') {
            $id_sv = $_REQUEST['id_sv'];
            $id_class = $_REQUEST['id_class'];
            DetailController::delete($id_sv, $id_class);
        }
        switch ($method) {
            case 'GET':
                StudentController::Detail($_REQUEST);
                return;
        }
    case 'join-class':
        switch ($method) {
            case 'GET':
                StudentController::join();
                return;
            case 'POST':
                DetailController::index($_REQUEST);
                return;
        }
    case 'major':
        if (isset($_GET['m']) && $_GET['m'] == 'delete') {
            DetailController::deleteMajor($_GET['id']);
        } else if (isset($_POST['btnUpdate'])) {
            DetailController::updateMajor($_REQUEST);
            return;
        }
        switch ($method) {
            case 'GET':
                DetailController::getMajor();
                return;
            case 'POST':
                DetailController::addMajor($_REQUEST);
                return;
        }
    case 'subject':
        if (isset($_GET['m']) && $_GET['m'] == 'delete') {
            DetailController::deleteSubject($_GET['id']);
        } else if (isset($_POST['btnUpdate'])) {
            DetailController::updateSubject($_REQUEST);
            return;
        }
        switch ($method) {
            case 'GET':
                DetailController::getSubject();
                return;
            case 'POST':
                DetailController::addSubject($_REQUEST);
                return;
        }
    case 'class':
        if (isset($_GET['m']) && $_GET['m'] == 'delete') {
            ClassController::delete($_REQUEST);
            return;
        } else if (isset($_POST['btnUpdate'])) {
            ClassController::update($_REQUEST);
            return;
        } else if (isset($_GET['m']) && $_GET['m'] == 'tim-kiem') {
            ClassController::Search();
            return;
        }
        switch ($method) {
            case 'GET':
                ClassController::index();
                return;
            case 'POST':
                ClassController::add($_REQUEST);
                return;
        }
    case 'cms-student':
        HomeController::index();
    
}
switch ($url) {
    case 'cms-home':
        HomeController::home();
}
switch ($url) {
    case 'cms-class':
        CMSClassController::index();
}
